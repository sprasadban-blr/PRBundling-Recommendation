sap.ui.define([
	"PRBUNDLE/PRBUNDLE/test/unit/controller/root.controller"
], function () {
	"use strict";
});